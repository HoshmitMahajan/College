#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define MAX 256
#define PORT 8080

// Function to reverse a string
void reverse_str(char *str) {
    int n = strlen(str);
    // Remove trailing newline or carriage return if present
    if (n > 0 && (str[n-1] == '\n' || str[n-1] == '\r')) {
        str[n-1] = '\0';
        n--;
    }
    for (int i = 0; i < n / 2; i++) {
        char temp = str[i];
        str[i] = str[n - 1 - i];
        str[n - 1 - i] = temp;
    }
}

int main() {
    int sockfd;
    struct sockaddr_in servaddr, cliaddr;
    char buffer[MAX];
    socklen_t len;

    // 1. Create UDP socket
    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    memset(&servaddr, 0, sizeof(servaddr));
    memset(&cliaddr, 0, sizeof(cliaddr));

    // 2. Fill server information
    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = INADDR_ANY;
    servaddr.sin_port = htons(PORT);

    // 3. Bind the socket
    if (bind(sockfd, (const struct sockaddr *)&servaddr, sizeof(servaddr)) < 0) {
        perror("Bind failed");
        exit(EXIT_FAILURE);
    }

    printf("UDP Reverse Server listening on port %d...\n", PORT);

    len = sizeof(cliaddr);
    for (;;) {
        memset(buffer, 0, MAX);
        
        // Receive packet from client
        int n = recvfrom(sockfd, (char *)buffer, MAX, MSG_WAITALL, (struct sockaddr *)&cliaddr, &len);
        buffer[n] = '\0';

        if (strncmp(buffer, "exit", 4) == 0) {
            printf("Client requested exit. Server shutting down...\n");
            break;
        }

        printf("Received string: %s", buffer);

        // Reverse the string
        reverse_str(buffer);
        
        // Append a newline back for clean output display
        strcat(buffer, "\n");

        // Send reversed string back to the client
        sendto(sockfd, (const char *)buffer, strlen(buffer), MSG_WAITALL, (const struct sockaddr *)&cliaddr, len);
    }

    close(sockfd);
    return 0;
}
