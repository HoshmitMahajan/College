#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define MAX 80
#define PORT 8080

void handle_client(int connfd) {
    char buff[MAX];
    for (;;) {
        memset(buff, 0, MAX);
        read(connfd, buff, sizeof(buff));

        if (strncmp("exit", buff, 4) == 0) {
            printf("Client requested exit. Server shutting down...\n");
            break;
        }

        printf("Received expression: %s", buff);

        double num1, num2, result = 0;
        char op;
        int valid = 1;

        if (sscanf(buff, "%lf %c %lf", &num1, &op, &num2) == 3) {
            switch (op) {
                case '+': result = num1 + num2; break;
                case '-': result = num1 - num2; break;
                case '*': result = num1 * num2; break;
                case '/': 
                    if (num2 != 0) result = num1 / num2;
                    else valid = 0;
                    break;
                default: valid = 0; break;
            }
        } else {
            valid = 0;
        }

        memset(buff, 0, MAX);
        if (valid) {
            snprintf(buff, MAX, "Result: %.2f\n", result);
        } else {
            snprintf(buff, MAX, "Invalid expression or division by zero!\n");
        }

        write(connfd, buff, sizeof(buff));
    }
}

int main() {
    int sockfd, connfd;
    struct sockaddr_in servaddr;

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == -1) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(PORT);

    if (bind(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) != 0) {
        perror("Socket bind failed");
        exit(EXIT_FAILURE);
    }

    if (listen(sockfd, 5) != 0) {
        perror("Listen failed");
        exit(EXIT_FAILURE);
    }
    printf("Server listening on port %d...\n", PORT);

    unsigned int len = sizeof(servaddr);
    connfd = accept(sockfd, (struct sockaddr*)&servaddr, &len);
    if (connfd < 0) {
        perror("Server accept failed");
        exit(EXIT_FAILURE);
    }
    printf("Client connected successfully.\n");

    handle_client(connfd);
    
    close(connfd);
    close(sockfd);
    return 0;
}
