#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define MAX 256
#define PORT 8080

int main() {
    int sockfd;
    struct sockaddr_in servaddr;
    char buffer[MAX];

    // 1. Create UDP socket
    if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    memset(&servaddr, 0, sizeof(servaddr));

    // 2. Fill server information
    servaddr.sin_family = AF_INET;
    servaddr.sin_port = htons(PORT);
    servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");

    socklen_t len = sizeof(servaddr);

    for (;;) {
        memset(buffer, 0, MAX);
        printf("Enter uppercase string (or 'exit'): ");
        if (fgets(buffer, MAX, stdin) == NULL) break;

        // Send string to server
        sendto(sockfd, (const char *)buffer, strlen(buffer), MSG_WAITALL, (const struct sockaddr *)&servaddr, sizeof(servaddr));

        if (strncmp(buffer, "exit", 4) == 0) {
            printf("Client exiting...\n");
            break;
        }

        // Receive response from server
        memset(buffer, 0, MAX);
        int n = recvfrom(sockfd, (char *)buffer, MAX, MSG_WAITALL, (struct sockaddr *)&servaddr, &len);
        buffer[n] = '\0';
        
        printf("Lowercase from server: %s", buffer);
    }

    close(sockfd);
    return 0;
}