#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>

#define MAX 256
#define PORT 8080

void handle_chat(int connfd) {
    char buff[MAX];
    for (;;) {
        // 1. Read message from client
        memset(buff, 0, MAX);
        ssize_t bytes_read = read(connfd, buff, sizeof(buff));
        if (bytes_read <= 0) {
            printf("Client disconnected.\n");
            break;
        }

        // Check if client wants to exit
        if (strncmp("exit", buff, 4) == 0) {
            printf("Client has left the chat.\n");
            break;
        }

        printf("Client: %s", buff);

        // 2. Send reply from server terminal
        memset(buff, 0, MAX);
        printf("Server (You): ");
        if (fgets(buff, sizeof(buff), stdin) == NULL) break;

        write(connfd, buff, sizeof(buff));

        // Check if server wants to exit
        if (strncmp(buff, "exit", 4) == 0) {
            printf("Chat ended by server.\n");
            break;
        }
    }
}

int main() {
    int sockfd, connfd;
    struct sockaddr_in servaddr;

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == -1) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = htonl(INADDR_ANY);
    servaddr.sin_port = htons(PORT);

    if (bind(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) != 0) {
        perror("Socket bind failed");
        exit(EXIT_FAILURE);
    }

    if (listen(sockfd, 5) != 0) {
        perror("Listen failed");
        exit(EXIT_FAILURE);
    }
    printf("Chat Server listening on port %d...\n", PORT);

    unsigned int len = sizeof(servaddr);
    connfd = accept(sockfd, (struct sockaddr*)&servaddr, &len);
    if (connfd < 0) {
        perror("Server accept failed");
        exit(EXIT_FAILURE);
    }
    printf("Client connected! Start chatting (type 'exit' to quit).\n");

    handle_chat(connfd);
    
    close(connfd);
    close(sockfd);
    return 0;
}
