#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define MAX 80
#define PORT 8080

void run_client(int sockfd) {
    char buff[MAX];
    for (;;) {
        memset(buff, 0, sizeof(buff));
        printf("Enter expression (e.g., 10 + 5) or 'exit': ");
        
        if (fgets(buff, sizeof(buff), stdin) == NULL) break;

        write(sockfd, buff, sizeof(buff));

        if (strncmp(buff, "exit", 4) == 0) {
            printf("Client exiting...\n");
            break;
        }

        memset(buff, 0, sizeof(buff));
        read(sockfd, buff, sizeof(buff));
        printf("%s", buff);
    }
}

int main() {
    int sockfd;
    struct sockaddr_in servaddr;

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == -1) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
    servaddr.sin_port = htons(PORT);

    if (connect(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) != 0) {
        perror("Connection to the server failed");
        exit(EXIT_FAILURE);
    }
    printf("Connected to the server.\n");

    run_client(sockfd);
    
    close(sockfd);
    return 0;
}
