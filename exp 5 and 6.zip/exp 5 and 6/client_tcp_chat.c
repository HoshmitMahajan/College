#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define MAX 256
#define PORT 8080

void run_chat(int sockfd) {
    char buff[MAX];
    for (;;) {
        // 1. Send message from client terminal
        memset(buff, 0, sizeof(buff));
        printf("Client (You): ");
        if (fgets(buff, sizeof(buff), stdin) == NULL) break;

        write(sockfd, buff, sizeof(buff));

        // Check if client wants to exit
        if (strncmp(buff, "exit", 4) == 0) {
            printf("Exiting chat...\n");
            break;
        }

        // 2. Read reply from server
        memset(buff, 0, sizeof(buff));
        ssize_t bytes_read = read(sockfd, buff, sizeof(buff));
        if (bytes_read <= 0) {
            printf("Server disconnected.\n");
            break;
        }

        // Check if server ended the chat
        if (strncmp(buff, "exit", 4) == 0) {
            printf("Server has ended the chat.\n");
            break;
        }

        printf("Server: %s", buff);
    }
}

int main() {
    int sockfd;
    struct sockaddr_in servaddr;

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == -1) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    servaddr.sin_family = AF_INET;
    servaddr.sin_addr.s_addr = inet_addr("127.0.0.1");
    servaddr.sin_port = htons(PORT);

    if (connect(sockfd, (struct sockaddr*)&servaddr, sizeof(servaddr)) != 0) {
        perror("Connection to the server failed");
        exit(EXIT_FAILURE);
    }
    printf("Connected to the chat server! (type 'exit' to quit).\n");

    run_chat(sockfd);
    
    close(sockfd);
    return 0;
}